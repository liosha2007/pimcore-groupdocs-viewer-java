GroupDocs Viewer for Java plugin for PimCore (Source code)
====================================

Code example 

```php
<?php $groupDocs = new GroupDocsViewerJava_GroupDocs(array( 'url' => 'http://plugins-qa.groupdocs.dynabic.com:3000', 'width' => '100%', 'height' => '600px', 'useHttpHandlers' => false )); ?>
<?php echo $groupDocs->renderViewer(); ?>
```